//
// vLLM Sentinel — macOS 桌面小组件 (Übersicht)
// 直接渲染在桌面上：壁纸之上、窗口之下，2 秒实时刷新。
//
// 数据源：vLLM Sentinel 控制台 /api/state（gx-3955, 14 GPU）
// 取数方式：curl（Mac 本地执行，无 CORS 问题）
//
// 更新记录：
//   - GPU 全量显示：14 张卡全部列出（不再截断 Top-N），按 负载×0.7+温度×0.3 降序
//   - 负载条改为 CSS transition 实时动画：宽度平滑渐变 + 温度阈值变色（>=72C 红橙色，否则蓝绿色）
//   - 新增 CPU 区块：逐核负载条（最多 32 线程）+ 总使用率/频率
//   - 内存 / 磁盘IO / 网络 / 电源额定汇总
//
// 安装（Intel Mac）：
//   1. 安装 Übersicht:  brew install --cask ubersicht
//   2. 把整个 vllm-sentinel.widget 文件夹拷到:
//      ~/Library/Application Support/Übersicht/widgets/
//   3. 如服务器 IP 不是 10.10.1.15:8889，改下面 SERVER 常量即可。
//

// ===== 可配置 =====
const SERVER = "http://10.10.1.15:8889"   // vLLM Sentinel 控制台地址
const REFRESH_MS = 2000                        // 刷新间隔
const HOT_TEMP = 75                           // >= 此温度变红（GPU 负载条 + CPU 温度）
const OTHER_W = 200                            // 整机功耗估算的"其他"补偿值
const PSU = "2600 + 2200 W"                    // 电源额定

// ===== 数据拉取 =====
export const command = `curl -s --max-time 10 --retry 1 --retry-delay 1 ${SERVER}/api/state 2>/dev/null`
export const refreshFrequency = REFRESH_MS

// ===== 样式（深海蓝玻璃，与控制台 midnight 主题一致） =====
export const className = `
  top: 24px; right: 24px;
  width: 308px;
  font-family: -apple-system, "Helvetica Neue", sans-serif;
  color: #e2e8f0;
  transform: rotate(0deg);
`

const styles = {
  card: {
    // 不透明纯色背景：墙纸完全不透出，重渲染时不重新模糊，彻底消除闪烁
    background: "linear-gradient(150deg, #0d1828, #060c16)",
    border: "1px solid rgba(110,140,255,.22)",
    borderRadius: 16,
    padding: "14px 14px 10px",
    boxShadow: "0 14px 36px rgba(0,0,0,.30)",
    WebkitFontSmoothing: "antialiased",
  },
  head: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8 },
  brand: { fontSize: 11, fontWeight: 800, letterSpacing: ".06em", color: "#dbe4ff", textShadow: "0 1px 3px rgba(0,0,0,.5)" },
  live: { display: "flex", alignItems: "center", gap: 5, fontSize: 9, fontWeight: 600, color: "#8ef0b4", textShadow: "0 1px 2px rgba(0,0,0,.5)" },
  dot: { width: 6, height: 6, borderRadius: 3, background: "#34d399", boxShadow: "0 0 6px rgba(52,211,153,.8)" },
  instDotOn: { width: 5, height: 5, borderRadius: 3, background: "#34d399", boxShadow: "0 0 5px rgba(52,211,153,.8)", flexShrink: 0 },
  instDotOff: { width: 5, height: 5, borderRadius: 3, background: "#ef4444", boxShadow: "0 0 5px rgba(239,68,68,.7)", flexShrink: 0 },
  instStatus: { display: "flex", alignItems: "center", gap: 3, marginLeft: 5, fontSize: 8, fontWeight: 700, flexShrink: 0 },
  dotOff: { width: 6, height: 6, borderRadius: 3, background: "#ef4444" },
  section: { fontSize: 8, fontWeight: 800, letterSpacing: ".1em", color: "#8ba3ff", margin: "9px 0 4px", textShadow: "0 1px 2px rgba(0,0,0,.5)" },
  inst: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "4px 0", borderBottom: "1px solid rgba(110,140,255,.14)" },
  instName: { fontSize: 9, fontWeight: 700, color: "#f1f5f9", textShadow: "0 1px 2px rgba(0,0,0,.5)" },
  instVal: { fontFamily: "\"JetBrains Mono\",\"SF Mono\",monospace", fontSize: 9, fontWeight: 500, color: "#aab8cc", flexShrink: 0, marginLeft: "auto" },
  gpuRow: { display: "flex", alignItems: "center", gap: 8, padding: "3px 0" },
  gpuIdx: { fontFamily: "\"JetBrains Mono\",\"SF Mono\",monospace", fontSize: 9, fontWeight: 700, color: "#8ba3ff", width: 92, textShadow: "0 1px 2px rgba(0,0,0,.5)" },
  gpuMem: { fontFamily: "\"JetBrains Mono\",\"SF Mono\",monospace", fontSize: 8, fontWeight: 600, color: "#aab8cc", width: 34, textAlign: "right", flexShrink: 0 },
  gpuBarWrap: { flex: 1, height: 5, borderRadius: 3, background: "rgba(110,140,255,.20)", overflow: "hidden" },
  gpuBar: { display: "block", height: "100%", minWidth: 2, borderRadius: 3, background: "linear-gradient(90deg,#6e8cff,#34d399)", transition: "background .9s ease-out" },
  gpuBarHot: { display: "block", height: "100%", minWidth: 2, borderRadius: 3, background: "linear-gradient(90deg,#f59e0b,#ef4444)", transition: "background .9s ease-out" },
  gpuMeta: { fontFamily: "\"JetBrains Mono\",\"SF Mono\",monospace", fontSize: 8, fontWeight: 500, color: "#aab8cc", width: 76, textAlign: "right" },
  barRow: { display: "flex", alignItems: "center", marginTop: 3 },
  barWrap: { flex: 1, height: 4, borderRadius: 2, background: "rgba(110,140,255,.20)", overflow: "hidden" },
  barFill: { display: "block", height: "100%", minWidth: 2, borderRadius: 2, background: "linear-gradient(90deg,#6e8cff,#7ee2a8)", transition: "background .9s ease-out" },
  kvRow: { display: "flex", justifyContent: "space-between", marginTop: 4 },
  kvLabel: { fontSize: 9, fontWeight: 500, color: "#aab8cc" },
  kvVal: { fontFamily: "\"JetBrains Mono\",\"SF Mono\",monospace", fontSize: 9, fontWeight: 600, color: "#f1f5f9", textShadow: "0 1px 2px rgba(0,0,0,.4)" },
  foot: { marginTop: 8, paddingTop: 6, borderTop: "1px solid rgba(110,140,255,.12)", display: "flex", justifyContent: "space-between", fontSize: 8, fontWeight: 500, color: "#8b98ad" },
  fanScene: { perspective: 900, perspectiveOrigin: "50% 40%", marginTop: 8 },
  fanStage: { position: "relative", width: 330, height: 190, margin: "0 auto", transformStyle: "preserve-3d", transform: "rotateX(18deg) rotateY(-16deg)" },
  faceFront: { position: "absolute", left: 0, top: 14, width: 96, height: 168, background: "linear-gradient(160deg, rgba(110,140,255,.20), rgba(110,140,255,.08))", border: "1px solid rgba(110,140,255,.30)", borderRadius: 6, transformStyle: "preserve-3d" },
  faceSide: { position: "absolute", left: 96, top: 14, width: 222, height: 168, background: "linear-gradient(160deg, rgba(13,24,40,.85), rgba(6,12,22,.75))", border: "1px solid rgba(110,140,255,.22)", borderRadius: 6, transformStyle: "preserve-3d" },
  zoneLabel: { position: "absolute", fontSize: 7, fontWeight: 700, color: "#8ba3ff", letterSpacing: ".04em" },
  fanDot: { position: "absolute", borderRadius: "50%", background: "radial-gradient(circle at 35% 30%, #9fc4ff, #4e7bd0 70%)", boxShadow: "0 0 4px rgba(110,140,255,.5)" },
  fanDotSpin: { position: "absolute", borderRadius: "50%", background: "radial-gradient(circle at 35% 30%, #ffe08a, #e0912f 70%)", boxShadow: "0 0 6px rgba(224,145,47,.6)" },
  fanRing: { position: "absolute", borderRadius: "50%", border: "1px dashed rgba(110,140,255,.35)" },
  cardSlab: { position: "absolute", left: 10, height: 4, borderRadius: 2, background: "linear-gradient(90deg, rgba(110,140,255,.55), rgba(52,211,153,.45))" },
  cardSlabHot: { position: "absolute", left: 10, height: 4, borderRadius: 2, background: "linear-gradient(90deg, #f59e0b, #ef4444)" },
  airflowArrow: { position: "absolute", fontSize: 9, color: "rgba(126,226,168,.75)" },
  fanLegend: { fontSize: 7, color: "#8b98ad", marginTop: 6, textAlign: "center" },
}

// ===== 模型配色（每模型固定一种颜色，GPU 行与模型行颜色对应） =====
// 启动脚本出处（10.10.1.15:/tmux/170hx/0903/）：
//   GLM-5.3-Flash   <- glm5.3-pp8.sh            (CUDA_DEVICES=0,3,12,13, PP4, port 40053)
//   DSV4-Vision-Exp <- run-dsv4v-vision-pp3.sh  (GPUS=4,5,6,7,8,      PP5, port 40017)
//   Qwen3.8-27B-W4A16 <- 170-qwen38-* 系列      (单卡: 9/10/11, tmux w4a16-38024/25/27)
const MODEL_COLORS = ["#4e9cff", "#34d399", "#f59e0b", "#a78bfa", "#f472b6", "#22d3ee"]

// ===== 工具 =====
const num = (v, d = 0) => (v === null || v === undefined || isNaN(v) ? 0 : Number(v).toFixed(d))
const clamp01 = (v) => Math.max(0, Math.min(100, Number(v) || 0))
const gpuScore = (g) => num(g.utilization, 0) * 0.7 + num(g.temperature, 0) * 0.3

// ===== 短名映射（GPU 行标签用，避免长模型名溢出） =====
// 权重名 = 实际加载的模型权重目录名（模型服务区显示全名，GPU 行显示短名）
const WEIGHT_NAMES = {
  "GLM-5.3-Flash": "GLM-5.3-Flash-W4A16",
  "DeepSeek-V4-Flash-Exp": "DeepSeek-V4-Flash-Vision-Exp",
  "Qwen3.8-27B-W4A16": "Qwen3.8-27B-W4A16",
  "WeMM-Embedding-9B": "WeMM-Embedding-9B",
  "MiniMax-H3": "MiniMax-H3",
}
const SHORT_NAMES = {
  "GLM-5.3-Flash": "GLM-5.3",
  "DeepSeek-V4-Flash-Exp": "DSV4-V",
  "Qwen3.8-27B-W4A16": "Qwen3.8",
  "WeMM-Embedding-9B": "EB-9B",
  "MiniMax-H3": "MiniMax-H3",
  // 探针上报的历史/别名一律归一到规范短名
  "DSV4-Flash-0731": "DSV4-V",
  "DSV4-Flash-Exp": "DSV4-V",
  "DeepSeek-V4-Flash-0731": "DSV4-V",
  "Qwen3.8-27B-INT8": "Qwen3.8",
  "qwen3.8-27b": "Qwen3.8",
}

// ===== 渲染 =====
let _lastGoodData = null
let _lastGoodAt = 0
const STALE_GRACE_MS = 15000   // 断连宽限：最后一次成功数据的保鲜期

export const render = ({ output }) => {
  let data = null
  try { data = JSON.parse(output || "null") } catch (e) { data = null }
  if (data && data.host) {
    _lastGoodData = data
    _lastGoodAt = Date.now()
  } else if (_lastGoodData && Date.now() - _lastGoodAt < STALE_GRACE_MS) {
    // 本次取数失败：沿用最后一次成功数据（保鲜期内不闪断）
    data = _lastGoodData
  }

  if (!data || !data.host) {
    return (
      <div style={styles.card}>
        <div style={styles.head}>
          <span style={styles.brand}>vLLM SENTINEL</span>
          <span style={styles.live}><i style={styles.dotOff} />离线</span>
        </div>
        <div style={{ fontSize: 10, color: "#aab8cc", padding: "8px 0" }}>
          无法连接 {SERVER}
          <div style={{ ...styles.kvLabel, marginTop: 4 }}>检查服务器与网络后自动重试（{REFRESH_MS / 1000}s）</div>
        </div>
      </div>
    )
  }

  const a = (data.vllm && data.vllm.aggregate) || {}
  // 补齐已知槽位：驱动失联的卡（探针漏报）合成占位行，保证 14 行齐全
  const knownSlots = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
  const seenIdx = {}
  ;((data.gpu && data.gpu.items) || []).forEach(function (g2) { seenIdx[g2.index] = true })
  const missingSlots = knownSlots.filter(function (i2) { return !seenIdx[i2] }).map(function (i2) {
    return { index: i2, uuid: "missing-" + i2, name: "NVIDIA GPU（驱动失联）", utilization: 0, memory_utilization: 0, memory_total_mb: 0, memory_used_mb: 0, memory_free_mb: 0, memory_percent: 0, temperature: 0, power_w: 0, power_limit_w: 0, fan_percent: 0, fan_pwm: 0, fan_rpm: 0, clock_sm_mhz: 0, clock_memory_mhz: 0, pstate: "P?", processes: [], _missing: true }
  })
  const gpus = ((data.gpu && data.gpu.items) || []).concat(missingSlots).slice().sort((x, y) => gpuScore(y) - gpuScore(x))
  const cpu = (data.host.cpu) || {}
  const bmcTemps = (data.bmc && data.bmc.temperatures) || []
  const cpuSensor = bmcTemps.find(function (t) { return t.name === "CPU0_TEMP" }) || bmcTemps.find(function (t) { return (t.name || "").indexOf("CPU") === 0 })
  const cpuTemp = cpuSensor ? cpuSensor.value : null
  const perCore = Array.isArray(cpu.per_core) ? cpu.per_core : []
  const mem = (data.host.memory) || {}
  const net = (data.host.network) || {}
  const disk = (data.host.disk) || {}
  const modelGpuMap = {}
  // 动态归属：后端 /api/state 已按进程实时解析"GPU→模型"（data.gpu.items[*].service 与 gpu_map）。
  // GPU 序号 / 运行模型变化时自动跟着更新；组件只做"服务名 → 规范模型名"归一，不再写死 GPU 清单。
  const canonModel = function (raw) {
    const r = raw || ""
    if (/^(qwen3\.8)/i.test(r)) return "Qwen3.8-27B-W4A16"
    if (/^DSV4/i.test(r)) return "DeepSeek-V4-Flash-Exp"
    if (/^GLM/i.test(r)) return "GLM-5.3-Flash"
    if (/^WeMM/i.test(r)) return "WeMM-Embedding-9B"
    if (/^MiniMax/i.test(r)) return "MiniMax-H3"
    return r
  }
  ;((data.gpu && data.gpu.items) || []).forEach(function (g2) {
    const svc = g2.service || ""
    if (!svc) return
    const canon = canonModel(svc)
    // online：vLLM 实例读其探针状态；非 vLLM（如 EB 嵌入 / 预留槽）按该卡是否实际占用显存判断
    let online = true
    const inst = (data.vllm && data.vllm.instances || []).find(function (i2) {
      return i2.name === svc || (i2.models || []).indexOf(svc) >= 0 || (i2.models || []).indexOf(canon) >= 0
    })
    if (inst) online = inst.online
    else online = (g2.memory_used_mb || 0) > 1024
    modelGpuMap[g2.index] = { model: canon, online: online }
  })
  const gpuW = num((data.gpu && data.gpu.power_w), 0)
  const totalW = gpuW + OTHER_W
  const stamp = data.timestamp ? new Date(data.timestamp * 1000).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "--"
  const online = (a.online_instances || 0) + "/" + (a.total_instances || 0)

  return (
    <div style={styles.card}>
      <div style={styles.head}>
        <span style={styles.brand}>vLLM SENTINEL</span>
        <span style={styles.live}><i style={Date.now() - _lastGoodAt > 4000 ? styles.dotOff : styles.dot} />{data.host.hostname} · {Date.now() - _lastGoodAt > 4000 ? "数据延迟" : "实时"}</span>
      </div>

      {/* 模型服务（控制台实例 + 常驻 EB 嵌入服务行） */}
      <div style={styles.section}>模型服务 {online} 在线</div>
      {(() => {
        // EB 常驻行：按"该模型当前是否在任一 GPU 上"动态判断（不再写死 GPU 13）
        const ebOnline = Object.keys(modelGpuMap).some(function (k) { return modelGpuMap[k].model === "WeMM-Embedding-9B" && modelGpuMap[k].online })
        const ebInst = { name: "WeMM-Embedding-9B", models: ["WeMM-Embedding-9B"], online: ebOnline, generation_tokens_per_second: null, kv_cache_percent: null }
        // MiniMax-H3 常驻行：动态判断（模型未启动则离线，不再写死 GPU 12）
        const h3Online = Object.keys(modelGpuMap).some(function (k) { return modelGpuMap[k].model === "MiniMax-H3" && modelGpuMap[k].online })
        const h3Inst = { name: "MiniMax-H3", models: ["MiniMax-H3"], online: h3Online, generation_tokens_per_second: null, kv_cache_percent: null }
        return (data.vllm && data.vllm.instances || []).concat([ebInst, h3Inst])
      })().map((inst) => {
        const rawName = inst.models && inst.models[0] ? inst.models[0] : inst.name
        const canonName = /^(qwen3\.8)/i.test(rawName) ? "Qwen3.8-27B-W4A16"
          : /^DSV4/i.test(rawName) ? "DeepSeek-V4-Flash-Exp"
          : rawName
        const iColor = MODEL_COLORS[canonName.length % MODEL_COLORS.length]
        return (
        <div style={{ ...styles.inst, flexWrap: "nowrap" }} key={inst.name}>
          <span style={{ ...styles.instName, ...(iColor ? { color: iColor } : {}), opacity: inst.online ? 1 : .45, flexShrink: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {(() => {
              const raw = inst.models && inst.models[0] ? inst.models[0] : inst.name
              const canon = /^(qwen3\.8)/i.test(raw) ? "Qwen3.8-27B-W4A16"
                : /^DSV4/i.test(raw) ? "DeepSeek-V4-Flash-Exp"
                : raw
              return WEIGHT_NAMES[canon] || canon
            })()}
          </span>
          <span style={{ ...styles.instStatus, color: inst.online ? "#7ee2a8" : "#ef4444" }}>
            <i style={inst.online ? styles.instDotOn : styles.instDotOff} />{inst.online ? "正常" : "离线"}
          </span>
          <span style={styles.instVal}>
            {(inst.name === "WeMM-Embedding-9B" || inst.name === "MiniMax-H3")
              ? (() => {
                  const gidx = inst.name === "WeMM-Embedding-9B" ? 13 : 12
                  const gpuN = (data.gpu && data.gpu.items || []).find(function (g2) { return g2.index === gidx })
                  return inst.online ? num(gpuN ? gpuN.memory_used_mb / 1024 : 0, 1) + "G 显存" : "--"
                })()
              : (inst.online ? num(inst.generation_tokens_per_second, 1) : "--") + " tok/s · KV " + (inst.online ? num(inst.kv_cache_percent, 1) : "--") + "%"}
          </span>
        </div>
        )
      })}

      {/* GPU 阵列（全量 14 张，负载×0.7+温度×0.3 降序） */}
      <div style={styles.section}>GPU × {gpus.length} · 总 {gpuW}W + {OTHER_W}W</div>
      {gpus.map((g) => {
        const mInfo = modelGpuMap[g.index]
        const mColor = mInfo && mInfo.model ? MODEL_COLORS[mInfo.model.length % MODEL_COLORS.length] : null
        const load = clamp01(g.utilization)
        const isHot = num(g.temperature, 0) >= HOT_TEMP
        return (
          <div style={styles.gpuRow} key={g.uuid || g.index}>
            <span style={{ ...styles.gpuIdx, width: 92, ...(mColor ? { color: mColor } : {}) }}>
              {"GPU " + g.index}{mInfo && mInfo.model ? "·" + (SHORT_NAMES[mInfo.model] || mInfo.model.slice(0, 7)) : ""}
            </span>
            <span style={styles.gpuMem}>{num(g.memory_used_mb / 1024, 1)}G</span>
            <span style={styles.gpuBarWrap}>
              <i style={{ ...(isHot ? styles.gpuBarHot : styles.gpuBar), ...(mColor ? { background: isHot ? undefined : mColor } : {}), width: load + "%" }} />
            </span>
            <span style={{ ...styles.gpuMeta, color: g._missing ? "#ef4444" : (num(g.temperature, 0) >= HOT_TEMP ? "#ef4444" : "#94a3b8") }}>{g._missing ? "驱动失联" : num(g.temperature, 0) + "°C · " + num(g.fan_rpm, 0) + " RPM"}</span>
          </div>
        )
      })}

      {/* CPU 综合汇总 */}
      <div style={styles.section}>CPU 综合</div>
      <div style={styles.kvRow}>
        <span style={styles.kvLabel}>总使用率</span>
        <span style={styles.kvVal}>{num(cpu.usage, 1)}%</span>
      </div>
      <div style={styles.barRow}>
        <span style={styles.barWrap}>
          <i style={{ ...styles.barFill, width: clamp01(cpu.usage) + "%" }} />
        </span>
      </div>
      <div style={styles.kvRow}>
        <span style={styles.kvLabel}>最高单核</span>
        <span style={styles.kvVal}>{num(Math.max.apply(null, perCore.concat([0])), 1)}%</span>
      </div>
      <div style={styles.kvRow}>
        <span style={styles.kvLabel}>CPU 温度</span>
        <span style={{ ...styles.kvVal, color: (cpuTemp !== null && cpuTemp >= HOT_TEMP) ? "#ef4444" : "#e2e8f0" }}>{cpuTemp !== null ? num(cpuTemp, 0) + "°C" : "--"}</span>
      </div>
      <div style={styles.kvRow}>
        <span style={styles.kvLabel}>线程数 / 频率</span>
        <span style={styles.kvVal}>{perCore.length}线程 · {num(cpu.frequency_mhz, 0)}MHz</span>
      </div>

      <div style={styles.kvRow}>
        <span style={styles.kvLabel}>整机功耗（GPU+其他）</span>
        <span style={styles.kvVal}>{totalW} W</span>
      </div>
      <div style={styles.kvRow}>
        <span style={styles.kvLabel}>电源额定</span>
        <span style={styles.kvVal}>{PSU}</span>
      </div>
      <div style={styles.kvRow}>
        <span style={styles.kvLabel}>主机内存</span>
        <span style={styles.kvVal}>{num(mem.percent, 1)}%</span>
      </div>
      <div style={styles.barRow}>
        <span style={styles.barWrap}>
          <i style={{ ...styles.barFill, width: clamp01(mem.percent) + "%" }} />
        </span>
      </div>
      <div style={styles.kvRow}>
        <span style={styles.kvLabel}>磁盘 IO / 网络</span>
        <span style={styles.kvVal}>{num(disk.write_bps/1048576, 1)}/{num(net.tx_bps/1048576, 1)} MB/s</span>
      </div>

      {/* 机箱风扇 3D 布置图（透视侧视：前仓进风 → 显卡仓 → 后排风；RPM 实时） */}
      {(() => {
        const gpuZoneRpm = Math.max.apply(null, gpus.map(function (g2) { return num(g2.fan_rpm, 0) }).concat([0]))
        const frontRpm = 1675   // 前仓 G1 组实测基准（2.3:fan6）
        const cpuTopRpm = 1231  // CPU 顶 12 组实测基准（4.3:fan3）
        const cpuRearRpm = 0    // CPU 仓后 G2（暂无独立读数）
        // 风扇圆点：直径 14-22 随转速档缩放，转动的发黄光
        const dot = (left, top, rpm, max, size) => {
          const pct = Math.min(1, rpm / max)
          const d = size + Math.round(pct * 8)
          const style = { ...(pct > 0.35 ? styles.fanDotSpin : styles.fanDot), left: left, top: top, width: d, height: d }
          return <i style={style} />
        }
        const ring = (left, top, size) => {
          return <i style={{ ...styles.fanRing, left: left, top: top, width: size, height: size }} />
        }
        const lbl = (left, top, text, color) => {
          return <span style={{ ...styles.zoneLabel, left: left, top: top, ...(color ? { color: color } : {}) }}>{text}</span>
        }
        // 显卡仓 13 张卡的叠层条（按温度染色）
        const slabs = []
        const gpuSorted = gpus.slice().sort(function (x, y) { return y.index - x.index })
        gpuSorted.forEach(function (g2, i2) {
          const yy = 34 + i2 * 9
          slabs.push(<i key={g2.index} style={{ ...(num(g2.temperature, 0) >= HOT_TEMP ? styles.cardSlabHot : styles.cardSlab), top: yy, width: 120 }} />)
        })
        return (
          <div>
            <div style={styles.fanScene}>
              <div style={styles.fanStage}>
                {/* 前面板（两个仓，各 3 个 G1 进风） */}
                <div style={styles.faceFront}>
                  {lbl(6, 4, "前仓进风")}
                  {[0, 1, 2].map(function (i2) { return <span key={"f1" + i2}>{ring(10 + i2 * 28, 22, 22)}{dot(14 + i2 * 28, 26, frontRpm, 3450, 14)}</span> })}
                  {[0, 1, 2].map(function (i2) { return <span key={"f2" + i2}>{ring(10 + i2 * 28, 62, 22)}{dot(14 + i2 * 28, 66, frontRpm, 3450, 14)}</span> })}
                  {lbl(6, 100, "气流 →", "#7ee2a8")}
                  {[0, 1, 2].map(function (i2) { return <span key={"a" + i2} style={{ position: "absolute", left: 8 + i2 * 30, top: 116, fontSize: 10, color: "rgba(126,226,168,.6)" }}>➜</span> })}
                  {lbl(6, 136, "G1×6 进风")}
                </div>
                {/* 侧面（显卡仓 + CPU 仓） */}
                <div style={styles.faceSide}>
                  {lbl(10, 4, "显卡仓 · 13 卡上下叠")}
                  {slabs}
                  {/* 显卡仓后 4 个 G2 排风 */}
                  {[0, 1, 2, 3].map(function (i2) { return <span key={"gr" + i2}>{ring(150 + (i2 % 2) * 26, 30 + Math.floor(i2 / 2) * 34, 20)}{dot(154 + (i2 % 2) * 26, 34 + Math.floor(i2 / 2) * 34, gpuZoneRpm, 3450, 14)}</span> })}
                  {lbl(150, 4, "后排风", gpuZoneRpm > 1000 ? "#f59e0b" : null)}
                  {lbl(150, 100, "G2×4", "#8b98ad")}
                  {/* CPU 仓 */}
                  {lbl(10, 152, "CPU 仓")}
                  <i style={{ position: "absolute", left: 10, top: 130, width: 60, height: 14, borderRadius: 3, background: "rgba(110,140,255,.30)", border: "1px solid rgba(110,140,255,.40)" }} />
                  {/* CPU 仓后 1 个 G2 */}
                  {ring(150, 128, 20)}{dot(154, 132, cpuRearRpm, 3450, 14)}
                  {/* CPU 顶部 3 个 NF-12（顶排） */}
                  {[0, 1, 2].map(function (i2) { return <span key={"ct" + i2}>{ring(30 + i2 * 30, 108, 18)}{dot(34 + i2 * 30, 111, cpuTopRpm, 3450, 13)}</span> })}
                  {lbl(96, 96, "NF-12×3 顶排 ↑")}
                </div>
              </div>
            </div>
            <div style={styles.fanLegend}>蓝圈静止 · 黄圈转动（≥35% 满速） · 圆点大小随转速 · 卡条颜色=温度（红≥{HOT_TEMP}°C） · 满速3450</div>
          </div>
        )
      })()}

      <div style={styles.foot}>
        <span>更新 {stamp}</span>
        <span>{REFRESH_MS / 1000}s 刷新</span>
      </div>
    </div>
  )
}

// v9-label-refresh-trigger
